# 1.1 로컬 계정 사용 설정
Rename-LocalUser -Name "Administrator" -NewName "jcadmin"

wmic useraccount where "Name='Administrator'" rename jcadmin

wmic UserAccount where "Name='jcadmin'" set PasswordExpires=FALSE

net user /add jcadmin01 Users!234#

net user /add jcadmin02 Users!234#

net localgroup administrators jcadmin01 /add

net localgroup administrators jcadmin02 /add



# 1.3 암호 정책 설정, 6.7 로컬 보안 감사정책 설정
secedit /export /cfg c:\test.inf

echo '[Event Audit]
AuditSystemEvents = 0
AuditLogonEvents = 3
AuditObjectAccess = 0
AuditPrivilegeUse = 3
AuditPolicyChange = 0
AuditAccountManage = 3
AuditProcessTracking = 0
AuditDSAccess = 0
AuditAccountLogon = 3
[Version]
signature="$CHICAGO$"
Revision=1
[System Access]
MinimumPasswordAge = 0
MaximumPasswordAge = 90
MinimumPasswordLength = 9
PasswordComplexity = 1
PasswordHistorySize = 12
LockoutBadCount = 10
ResetLockoutCount = 30
LockoutDuration = 30
[Version]
signature="$CHICAGO$"
Revision=1' >> test.inf
secedit /configure /db test.sdb /cfg test.inf
del test.sdb
del test.inf



# 2.2 공유폴더 설정
net share C$ /delete
net share D$ /delete
net share E$ /delete
net share F$ /delete
net share ADMIN$ /delete
net share print$ /delete


Reg add HKLM\SYSTEM\CurrentControlSet\services\LanmanServer\Parameters /v AutoShareServer /t REG_DWORD /d 0 /f

net start server
net stop server



# 6.2 화면 보호기 설정
echo 'Windows Registry Editor Version 5.00

[HKEY_USERS\.DEFAULT\Control Panel\Desktop]
"ScreenSaveActive"="1"
"ScreenSaverIsSecure"="1"
"ScreenSaveTimeOut"="300"

[HKEY_USERS\.DEFAULT\Software\Policies\Microsoft\Windows\Control Panel\Desktop]
"ScreenSaveActive"="1"
"ScreenSaverIsSecure"="1"
"ScreenSaveTimeOut"="300"' >> scr.reg

regedit.exe /S ./scr.reg

Reg add "HKEY_USERS\.DEFAULT\Control Panel\Desktop" /v "SCRNSAVE.EXE" /t REG_SZ /d C:\Windows\system32\scrnsave.scr /f



# 6.4 로그인 시 경고 메시지 표시 설정
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "legalnoticecaption" -Value "Warning!"

Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "legalnoticetext" -Value "This system is for the use of authorized users only."

Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"  -Name "LegalNoticeCaption" -Value "Warning!"

Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"  -Name "LegalNoticeText" -Value "This system is for the use of authorized users only."



# 6.5 마지막 로그온 사용자 계정 숨김 설정
Reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v "dontdisplaylastusername" /t REG_DWORD /d 1 /f



# 6.8 가상 메모리 페이지 파일 삭제 설정
Reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v "ClearPageFileAtShutdown" /t REG_DWORD /d 1 /f



# 8.1 Null Session 설정
Reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa" /v "restrictanonymous" /t REG_DWORD /d 2 /f



# 8.2 Remote Registry 서비스 설정
net stop RemoteRegistry

Set-Service -Name "RemoteRegistry" -StartupType disabled



# 3.1 터미널 서비스 암호화 수준 설정
Reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" /v "MinEncryptionLevel" /t REG_DWORD /d 2 /f

# Reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" /v "UserAuthentication" /t REG_DWORD /d 0 /f

Reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" /v "MinEncryptionLevel" /t REG_DWORD /d 2 /f

Reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" /v "UserAuthentication" /t REG_DWORD /d 0 /f

Reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" /v "SecurityLayer" /t REG_DWORD /d 0 /f

# 6.6 로그온 하지 않은 사용자 시스템 종료 방지
Reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\policies\system" /v "shutdownwithoutlogon" /t REG_DWORD /d 0 /f
