echo "fields_under_root: true
fields: {system.service: ""webservice"", system.name: ""$(hostname)"", system.pri_ip: ""$(invoke-webrequest http://169.254.169.254/latest/meta-data/local-ipv4 -UseBasicParsing)"", system.pub_ip: ""$(invoke-webrequest http://169.254.169.254/latest/meta-data/public-ipv4 -UseBasicParsing)""}

winlogbeat.event_logs:
  - name: Application
    tags: [""windows_evt_application""]
  - name: Security
    tags: [""windows_evt_security""]
  - name: System
    tags: [""windows_evt_system""]
  - name: Setup
    tags: [""windows_evt_setup""]

processors:
  - add_host_metadata: ~
  - add_cloud_metadata: ~

logging.to_files: true
logging.files:
  path: C:/ProgramData/winlogbeat/Logs
logging.level: info

output.logstash:
  hosts: [""elk-private.joycityglobal.com:5044""]" > "C:/joycity-system/joycity-winlogbeat/winlogbeat.yml"

net stop winlogbeat
net start winlogbeat
